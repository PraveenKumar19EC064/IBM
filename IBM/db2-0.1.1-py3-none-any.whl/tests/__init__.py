#! usr/bin/python3.6

import sys
sys.path.append("../")

from db2.orm import Base

