#! usr/bin/python3.6


USER = 'root'
HOST = 'localhost'
DATABASE = 'eclinic'
PASSWORD = ''

DEBUG = False
